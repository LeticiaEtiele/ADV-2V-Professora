
//https://makitweb.com/how-to-capture-picture-from-webcam-with-webcam-js/
var camera = document.getElementById("camera");

//Código copiado da página da API
//Ajustar a altura e largura
Webcam.set({
  width:350,
  height:300,
  image_format : 'png',
  png_quality:90
});
Webcam.attach( '#camera' );

//Código para capturar a imagem   
function takeSnapshot()
{
    //Acionar uma função da API e solicitar acionamento da 
    //pré-visualização (data_uri) da imagem após a captura.
    Webcam.snap(function(data_uri) {
      //Atualizando o HTML para exibir a imagem
      document.getElementById("result").innerHTML = '<img src="'+data_uri+'" id="captured_image"/>';
    });
}


//BIBLIOTECA ML5
//utilizada para trabalhar com machine learning.
//https://amadolucas.github.io/C135-137/


//Testar o Ml5
console.log('ml5 version:', ml5.version);

//Importar nosso Ml (Teachable Machine) treinado para o Ml5
//*** IMPORTANTE *** Escrever "model.json" no final do link
//"imageClassifier" acionar a função de classificação
//"modelLoaded" iniciar a classificação de imagem
var classifier = ml5.imageClassifier('https://teachablemachine.withgoogle.com/models/v_sl95BzE/model.json',modelLoaded);

//Vamos testar se a função foi acionada
function modelLoaded() {
  console.log('Model Loaded!');
}




// PARTE 3

//Primeiro mostrar o array de decisão no console e como funcionam as %


function check()
{
  img = document.getElementById('captured_image');
  //Nota1: classify = função predefinida de ml5.js utilizada para comparar a imagem capturada com o modelo
  //Nota2: gotResult = função que receberá o resultado. Vamos criá-la mais adiante
  classifier.classify(img, gotResult);

}


function gotResult(error, results) {
  if (error) {
    console.error(error);
  } else {
    console.log(results);

    //O primeiro resultado da decisão é sempre o mais preciso, sendo assim, vamos buscar o índice 0 no array
    //Buscando o nome do resultado
    document.getElementById("resultObjectName").innerHTML = results[0].label;
    //Buscando o valor de certeza (confidence)
    document.getElementById("resultObjectAccuracy").innerHTML = results[0].confidence.toFixed(3);
  }
}

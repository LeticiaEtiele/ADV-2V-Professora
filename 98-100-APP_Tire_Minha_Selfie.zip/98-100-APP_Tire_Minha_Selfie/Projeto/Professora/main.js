//Armazenar a API Web Speech (Converte voz em texto)
//OBS: SpeechRecognition = Recohecimento de fala
var reconhecerFala = window.webkitSpeechRecognition;

//Nova API (Usar exemplo do João API Humano)
//Convertendo a voz em texto
var reconhecimento = new reconhecerFala();

function start(){
    //Manter a caixa de texto vazia
    document.getElementById("textbox").innerHTML = "";

    //Chamar função (pré-definida) da API Web Speech 
    reconhecimento.start();
} 
 
//Acessando a função que contém a conversão (voz em texto)
reconhecimento.onresult = function(event) {

    console.log(event); 
    console.log(results);

    //Acessando a frase convertida localizada dentro da API
    var frase = event.results[0][0].transcript;

    document.getElementById("textbox").innerHTML = frase;
    console.log(frase);
}    

    // AULA 99
    // Habilitar apenas quando a função speak for concluída
    // Nota: a idéia é automatizar a resposta
    // speak();


    //AULA 100
    // if(frase =="tire minha selfie"){
    //     console.log("tirando selfie --- ");
    //     speak();
    // }
//}

// AULA 99
function speak(){
    //Armazenar a API Text to Speech (Converte texto em voz)
    var fala = window.speechSynthesis; //OBS: speechSynthesis = Síntese de fala

    //Frase para ser convertida
    var fraseResposta = "Tirando sua selfie em 5 segundos";

    //Nova API (Mesmo exemplo do João API Humano)
    //Convertendo o texto em voz
    var falar = new SpeechSynthesisUtterance(fraseResposta);

    //Chamar função (pré-definida) da API Text-to-Speech
    fala.speak(falar);

    //Chamar WebCan
    //Código retirado da API Makitweb
    Webcam.attach("camera");
    


    //AULA 100
    //Programar para que a selfie seja tirada em 5 segundos
    //w3school exemplo: https://www.w3schools.com/code/tryit.asp?filename=GDME156RVQSU
    setTimeout(
        function(){ 
            //Funções criadas mais adiante (próxima aula)
            takeSelfie(); 
            save();
        }, 5000 //milissegundos
    );

}

//WEB CAN

//NOTA: 
//importar a biblioteca no HTML https://makitweb.com/how-to-capture-picture-from-webcam-with-webcam-js/

//Código copiado da página da API
//Ajustar a altura e largura
Webcam.set({
    width:360,
    height:250,
    image_format : 'jpeg',
    jpeg_quality:90
});



//AULA 100
//Código para capturar a imagem
function takeSelfie(){
    //snap = fção predefinida da API (webcam.js) utilizada para tirar uma selfie.
    //Essa função contém data_uri que pode ser utilizada para mostrar a foto tirada
    Webcam.snap(function(data_uri) {
        document.getElementById("result").innerHTML = '<img id="selfie_image" src="'+data_uri+'"/>';
    });
}

function save()
{
  var link = document.getElementById("link"); //tag ancora criada no inicio do HTML

  //guardar o endereço da imagem
  var image = document.getElementById("selfie_image").src ; //tag criada na fção "takeSelfie()"

  //Passando o endereço da imagem para a tag ancora
  link.href = image;

  //Automatizar o clique na tag ancora, 
  //pois queremos que o download da imagem seja feito automaticamente,
  link.click();
}
//AULA 104
var camera = document.getElementById("camera");

//LINK API
//https://makitweb.com/how-to-capture-picture-from-webcam-with-webcam-js/

//Ajustar a altura, largura e o id
Webcam.set({
  width:350,
  height:300,
  image_format : 'jpeg',
  png_quality:90
});
Webcam.attach( '#camera' );

//Código para capturar a imagem   
function takeSnapshot() {
    //Acionar função da API e
    //solicitar a pré-visualização da imagem após a captura (data_uri)
    Webcam.snap(function(data_uri) {
      document.getElementById("result").innerHTML = '<img src="'+data_uri+'" id="imagem_capturada"/>';
    });
}


//BIBLIOTECA ML5 (demonstrar a biblioteca)
//https://amadolucas.github.io/C135-137/


//Testar o Ml5
console.log('ml5 version:', ml5.version);

//Importar nosso Ml (Teachable Machine) treinado para o Ml5
//*** IMPORTANTE *** Escrever "model.json" no final do link
//"imageClassifier" aciona a função de classificação
//"modelLoaded" iniciar a classificação de imagem
var classifier = ml5.imageClassifier('https://teachablemachine.withgoogle.com/models/v_sl95BzE/model.json',modeloCarregado);

//Testar se a função foi acionada
function modeloCarregado() {
  console.log('Modelo Carregado!');
}




// PARTE 3

//Primeiro mostrar o array de decisão no console e como funcionam as %


function check() {
  img = document.getElementById('imagem_capturada');
  //Nota1: classify = função predefinida de ml5.js utilizada para comparar a imagem capturada com o modelo
  classifier.classify(img, gotResult);
}


function gotResult(error, results) {
  if (error) {
    console.error(error);
  } else {
    console.log(results);

    //O primeiro resultado da decisão é sempre o mais preciso, sendo assim, vamos buscar o índice 0 no array
    //Buscando o nome do resultado
    document.getElementById("resultObjectName").innerHTML = results[0].label;
    //Buscando o valor de certeza (confidence)
    document.getElementById("resultObjectAccuracy").innerHTML = results[0].confidence.toFixed(3) * 100;
  }
}
